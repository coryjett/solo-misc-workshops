<img src="https://img.shields.io/badge/Version-0.3.15-informational?style=flat-square" alt="Version: 0.3.15" align="left">

<br>Review Helm values for the `kagent-enterprise` Helm chart, which installs the Solo build of kagent open source.

## Overview

The kagent-enterprise chart deploys the Solo build of kagent open source, which installs core kagent components and specialized agents for Kubernetes environments including:
- kagent controller for managing agent lifecycles and configurations
- AI agents for Kubernetes (k8s, Istio, Helm, Argo Rollouts, Cilium, and more)
- MCP tools for extended functionality (Grafana, QueryDoc)
- Built-in kagent tools

For more information, see the [installation guide](https://docs.solo.io/kagent-enterprise/docs/latest/install/install-kagent/).

## Required Values

The following values **must** be configured for the kagent-enterprise chart to function:

| Parameter | Description | Why Required |
|-----------|-------------|--------------|
| `oidc.issuer` | OIDC identity provider issuer URL | Required for user authentication |
| `oidc.clientId` | OIDC client identifier | Required for OAuth2/OIDC flow |
| `oidc.secret` or `oidc.secretRef` | OIDC client secret or reference to secret | Required for secure authentication |
| `providers.*.apiKey` or `providers.*.apiKeySecretRef` | API key for LLM providers (OpenAI, Anthropic, etc.) | Required for AI agent functionality |

## Values

| Key | Type | Description | Default |
| --- | ---- | ----------- | ------- |
| agents.argo-rollouts-agent.enabled | bool | Enable Argo Rollouts agent for progressive delivery | `false` |
| agents.argo-rollouts-agent.resources | object | Resource requests and limits for argo-rollouts-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.cilium-debug-agent.enabled | bool | Enable Cilium debug agent for network troubleshooting | `false` |
| agents.cilium-debug-agent.resources | object | Resource requests and limits for cilium-debug-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.cilium-manager-agent.enabled | bool | Enable Cilium manager agent for CNI management | `false` |
| agents.cilium-manager-agent.resources | object | Resource requests and limits for cilium-manager-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.cilium-policy-agent.enabled | bool | Enable Cilium network policy agent | `false` |
| agents.cilium-policy-agent.resources | object | Resource requests and limits for cilium-policy-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.helm-agent.enabled | bool | Enable Helm agent for managing Helm releases | `false` |
| agents.helm-agent.resources | object | Resource requests and limits for helm-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.istio-agent.enabled | bool | Enable Istio service mesh agent | `false` |
| agents.istio-agent.resources | object | Resource requests and limits for istio-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.k8s-agent.enabled | bool | Enable Kubernetes agent for managing K8s resources | `false` |
| agents.k8s-agent.resources | object | Resource requests and limits for k8s-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.kgateway-agent.enabled | bool | Enable Kubernetes Gateway API agent | `false` |
| agents.kgateway-agent.resources | object | Resource requests and limits for kgateway-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.observability-agent.enabled | bool | Enable observability agent for metrics and monitoring | `false` |
| agents.observability-agent.resources | object | Resource requests and limits for observability-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| agents.promql-agent.enabled | bool | Enable PromQL agent for Prometheus queries | `false` |
| agents.promql-agent.resources | object | Resource requests and limits for promql-agent | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| controller.a2aBaseUrl | string | The base URL of the A2A Server endpoint, as advertised to clients. | `http://<fullname>-controller.<namespace>.svc.cluster.local:<port>` |
| controller.agentDeployment | object | Global deployment defaults applied to all agent pods. Per-agent settings in the Agent CRD take precedence over these defaults. | `{"podLabels":{},"serviceAccountName":""}` |
| controller.agentDeployment.podLabels | object | Default labels applied to all agent pod templates. Per-agent labels in the Agent CRD take precedence over these defaults. | {} (no extra labels) |
| controller.agentDeployment.serviceAccountName | string | Default ServiceAccount name for agent pods. When set, agent pods that don't specify an explicit serviceAccountName will use this ServiceAccount instead of creating a per-agent one. Useful for Workload Identity (GCP, AWS IRSA, Azure Workload Identity). Precedence: agent-level serviceAccountName > this default > auto-created SA. | "" (auto-create per-agent ServiceAccount) |
| controller.agentImage.pullPolicy | string | Image pull policy for agent images | `""` |
| controller.agentImage.registry | string | Container registry for agent images | `""` |
| controller.agentImage.repository | string | Repository for agent images | `"kagent-dev/kagent/app"` |
| controller.agentImage.tag | string | Tag for agent images. | `"0.8.5"` |
| controller.env | list | Additional environment variables for controller | `[]` |
| controller.envFrom | list | Additional envFrom sources for controller (e.g. secretRef). Controller ConfigMap is always included. | `[]` |
| controller.image.name | string | Image name for the controller image. | `"kagent-enterprise-controller"` |
| controller.image.pullPolicy | string | Image pull policy for controller | `""` |
| controller.image.registry | string | Container registry for the controller image. | `"us-docker.pkg.dev/solo-public"` |
| controller.image.repository | string | Repository path for the controller image. | `"kagent-enterprise"` |
| controller.image.tag | string | Image tag for the controller image. If unset, defaults to the chart version. | `""` |
| controller.istioAuthzTranslation.enabled | bool | Enable Istio authorization for access policies and waypoint label on Agents | `false` |
| controller.loglevel | string | Log level for the controller (debug, info, warn, error) | `"info"` |
| controller.nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| controller.replicas | int | Number of controller replicas | `1` |
| controller.resources | object | Resource requests and limits for controller | `{"limits":{"cpu":2,"memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| controller.service.ports.port | int | Service port for controller | `8083` |
| controller.service.ports.targetPort | int | Target port for controller | `8083` |
| controller.service.type | string | Service type for controller | `"ClusterIP"` |
| controller.skillsInitImage | object | The image used by the skills-init container to clone skills from Git and pull OCI skill images. | `{"pullPolicy":"","registry":"","repository":"kagent-dev/kagent/skills-init","tag":"0.8.5"}` |
| controller.streaming | object | Streaming buffer configuration for agent-to-agent (A2A) communication | `{"initialBufSize":"4Ki","maxBufSize":"1Mi","timeout":"600s"}` |
| controller.streaming.initialBufSize | string | Initial buffer size for streaming | `"4Ki"` |
| controller.streaming.maxBufSize | string | Maximum buffer size for streaming | `"1Mi"` |
| controller.streaming.timeout | string | Timeout for streaming operations | `"600s"` |
| controller.tolerations | list | Node taints to be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| controller.volumeMounts | list | Additional volumeMounts on the controller container. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| controller.volumes | list | Additional volumes on the controller Deployment. Useful for mounting license keys from external secret stores (e.g. CSI / Google Secret Manager). Required when using licensing.licenseFilePath. | `[]` |
| controller.watchNamespaces | list | Namespaces the controller should watch. If empty (default), the controller will watch ALL available namespaces. | [] |
| database.postgres.bundled | object | Bundled PostgreSQL instance — for development and evaluation only. Not suitable for production. Deployed when enabled is true and url/urlFile are not set. | `{"enabled":true,"image":{"name":"postgres","pullPolicy":"IfNotPresent","registry":"docker.io","repository":"library","tag":"18"},"podSecurityContext":{"fsGroup":999,"runAsGroup":999,"runAsNonRoot":true,"runAsUser":999,"seccompProfile":{"type":"RuntimeDefault"}},"resources":{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"250m","memory":"256Mi"}},"securityContext":{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"seccompProfile":{"type":"RuntimeDefault"}},"storage":"500Mi","storageClassName":""}` |
| database.postgres.bundled.enabled | bool | Set to false to disable the bundled database and provide your own via url or urlFile. | `true` |
| database.postgres.bundled.image.name | string | Bundled PostgreSQL image name | `"postgres"` |
| database.postgres.bundled.image.pullPolicy | string | Bundled PostgreSQL image pull policy | `"IfNotPresent"` |
| database.postgres.bundled.image.registry | string | Bundled PostgreSQL image registry | `"docker.io"` |
| database.postgres.bundled.image.repository | string | Bundled PostgreSQL image repository (org/namespace) | `"library"` |
| database.postgres.bundled.image.tag | string | Bundled PostgreSQL image tag | `"18"` |
| database.postgres.bundled.podSecurityContext | object | Pod-level security context for the bundled PostgreSQL deployment. | `{"fsGroup":999,"runAsGroup":999,"runAsNonRoot":true,"runAsUser":999,"seccompProfile":{"type":"RuntimeDefault"}}` |
| database.postgres.bundled.resources | object | Resource requests/limits for the demo PostgreSQL container | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"250m","memory":"256Mi"}}` |
| database.postgres.bundled.securityContext | object | Container-level security context for the bundled PostgreSQL container. | `{"allowPrivilegeEscalation":false,"capabilities":{"drop":["ALL"]},"seccompProfile":{"type":"RuntimeDefault"}}` |
| database.postgres.bundled.storage | string | PersistentVolumeClaim size for demo PostgreSQL data | `"500Mi"` |
| database.postgres.bundled.storageClassName | string | StorageClass for the PostgreSQL PVC. Defaults to the cluster default when empty. | `""` |
| database.postgres.url | string | External PostgreSQL connection string. Is always used if set regardless of the `.bundled.enabled` field. | `""` |
| database.postgres.urlFile | string | Path to a file containing the database URL. Takes precedence over url when set. Is always used if set regardless of the `.bundled.enabled` field. | `""` |
| database.postgres.vectorEnabled | bool | Enable the pgvector migration Required to use features that depend on database vector capability. (e.g. long-term memory) Set to true when using an external PostgreSQL that has the pgvector extension installed. | `false` |
| fullnameOverride | string | Override the full name of the chart | `"kagent"` |
| grafana-mcp.fullnameOverride | string |  | `"kagent-grafana-mcp"` |
| grafana-mcp.grafana.apiKey | string | Grafana API key | `"-"` |
| grafana-mcp.grafana.url | string | Grafana API URL | `"grafana.kagent:3000/api"` |
| grafana-mcp.resources | object | Resource requests and limits for grafana-mcp | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| imagePullPolicy | string | Image pull policy for all components | `"IfNotPresent"` |
| imagePullSecrets | list | Image pull secrets for private registries | `[]` |
| kagent-tools.enabled | bool | Enable kagent-tools deployment | `false` |
| kagent-tools.fullnameOverride | string | Override the full name for kagent-tools | `"kagent-tools"` |
| kagent-tools.replicaCount | int | Number of kagent-tools replicas | `1` |
| kagent-tools.resources | object | Resource requests and limits for kagent-tools | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| kagent-tools.tools.k8s.tokenPassthrough | bool | Require token from auth header for kubectl (when true). Default false: use in-cluster SA token. | `false` |
| kagent-tools.tools.loglevel | string | Log level for kagent-tools | `"debug"` |
| kagent-tools.tools.metrics.port | int |  | `8085` |
| kagent-tools.useDefaultServiceAccount | bool | Use default service account (no RBAC). Set to true to use default SA; false creates a dedicated SA and ClusterRole/ClusterRoleBinding | `false` |
| kmcp.enabled | bool | Enable kmcp deployment | `true` |
| kmcp.image | object | Image configuration (only override enterprise-specific values) | `{"name":"kmcp-enterprise-controller","pullPolicy":"","registry":"us-docker.pkg.dev/solo-public","repository":"kagent-enterprise","tag":""}` |
| kmcp.image.name | string | Image name | `"kmcp-enterprise-controller"` |
| kmcp.image.pullPolicy | string | Image pull policy | `""` |
| kmcp.image.registry | string | Container registry | `"us-docker.pkg.dev/solo-public"` |
| kmcp.image.repository | string | Image repository | `"kagent-enterprise"` |
| kmcp.image.tag | string | Tag for the image If unset, defaults to the global tag, then to the chart version. | `""` |
| kmcp.resources | object | Resource limits and requests (override upstream defaults for enterprise) | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| kubernetes.jwksUrl | string | Override the JWKS discovery URL for Kubernetes service account token validation (optional). When not set, JWKS is discovered using the well-known OIDC endpoint on the cluster's api server | `""` |
| labels | object | Additional labels to add to all Kubernetes resources | `{}` |
| licensing.createSecret | bool | When true the chart creates a Secret from licenseKey. If you use your own Secret, set this to false and provide the secret name in secretName. | `true` |
| licensing.licenseFilePath | string | Absolute path to the license key file inside a mounted volume (e.g. CSI / Google Secret Manager). Sets ENTERPRISE_KAGENT_LICENSE_KEY_PATH; the controller reads the license key from this file at startup. You must also configure the volume source and mount via controller.volumes and controller.volumeMounts so the file actually exists at this path inside the container. When set, takes precedence over secretName. Example: /etc/kagent/enterprise-kagent-license-key | `nil` |
| licensing.licenseKey | string | Contact Sales if you do not have an Enterprise kagent license key. | `nil` |
| licensing.secretName | string | Name of the Secret containing the Solo Enterprise for kagent license key (key: enterprise-kagent-license-key). | `"enterprise-kagent-license"` |
| nameOverride | string | Override the name of the chart | `""` |
| namespaceOverride | string | Override the namespace | `.Release.Namespace` |
| nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| oidc.clientId | string | OIDC client identifier | `"kagent-enterprise"` |
| oidc.issuer | string | OIDC identity provider issuer URL | `""` |
| oidc.oboClaimsToPropagate | list | OBO claims to propagate | `[]` |
| oidc.secret | string | OIDC client secret (if secretRef is not used) | `""` |
| oidc.secretKey | string | OIDC secret key that the secret is associated with | `"clientSecret"` |
| oidc.secretRef | string | Reference to existing secret containing OIDC client secret | `"kagent-enterprise-oidc-secret"` |
| oidc.skipOBO | bool | Skip OBO token generation and pass through original user token (default: false) | `false` |
| otel.logging.enabled | bool | Enable OpenTelemetry logging | `false` |
| otel.logging.exporter.otlp.endpoint | string |  | `""` |
| otel.logging.exporter.otlp.insecure | bool | Use insecure connection for log export | `true` |
| otel.logging.exporter.otlp.timeout | int | OTLP timeout in milliseconds. | `15000` |
| otel.tracing.enabled | bool | Enable OpenTelemetry tracing | `false` |
| otel.tracing.exporter.otlp.endpoint | string |  | `""` |
| otel.tracing.exporter.otlp.insecure | bool | Use insecure connection for trace export | `true` |
| otel.tracing.exporter.otlp.protocol | string |  | `"grpc"` |
| otel.tracing.exporter.otlp.timeout | int | OTLP timeout in milliseconds. | `15000` |
| podAnnotations | object | Additional annotations to add to all pods | `{}` |
| podSecurityContext | object | Security context for all pods | `{"runAsNonRoot":true}` |
| providers.anthropic.apiKeySecretKey | string | Key in secret containing the API key | `"ANTHROPIC_API_KEY"` |
| providers.anthropic.apiKeySecretRef | string | Name of secret containing Anthropic API key | `"kagent-anthropic"` |
| providers.anthropic.model | string | Anthropic model to use | `"claude-haiku-4-5-20251001"` |
| providers.anthropic.provider | string | Provider name | `"Anthropic"` |
| providers.azureOpenAI.apiKeySecretKey | string | Key in secret containing the API key | `"AZUREOPENAI_API_KEY"` |
| providers.azureOpenAI.apiKeySecretRef | string | Name of secret containing Azure OpenAI API key | `"kagent-azure-openai"` |
| providers.azureOpenAI.config | object | Azure OpenAI configuration | `{"apiVersion":"2023-05-15","azureAdToken":"","azureDeployment":"","azureEndpoint":""}` |
| providers.azureOpenAI.config.apiVersion | string | Azure OpenAI API version | `"2023-05-15"` |
| providers.azureOpenAI.config.azureAdToken | string | Azure AD token for authentication | `""` |
| providers.azureOpenAI.config.azureDeployment | string | Azure OpenAI deployment name | `""` |
| providers.azureOpenAI.config.azureEndpoint | string | Azure OpenAI endpoint URL | `""` |
| providers.azureOpenAI.model | string | Azure OpenAI model to use | `"gpt-4.1-mini"` |
| providers.azureOpenAI.provider | string | Provider name | `"AzureOpenAI"` |
| providers.bedrock.apiKeySecretKey | string | Key in secret containing the AWS access key ID | `"AWS_ACCESS_KEY_ID"` |
| providers.bedrock.apiKeySecretRef | string | Name of secret containing AWS credentials (access key ID and secret access key) | `"kagent-bedrock"` |
| providers.bedrock.config | object | AWS Bedrock configuration | `{"region":"us-east-1"}` |
| providers.bedrock.config.region | string | AWS region where the Bedrock model is available (e.g., us-east-1, us-west-2) | `"us-east-1"` |
| providers.bedrock.model | string | AWS Bedrock model to use (e.g., anthropic.claude-3-5-sonnet-20241022-v2:0) | `"anthropic.claude-3-5-sonnet-20241022-v2:0"` |
| providers.bedrock.provider | string | Provider name | `"Bedrock"` |
| providers.default | string | Default LLM provider to use. Update if you use another provider. | `"openAI"` |
| providers.gemini.apiKeySecretKey | string | Key in secret containing the API key | `"GOOGLE_API_KEY"` |
| providers.gemini.apiKeySecretRef | string | Name of secret containing Gemini API key | `"kagent-gemini"` |
| providers.gemini.model | string | Gemini model to use | `"gemini-2.0-flash-lite"` |
| providers.gemini.provider | string | Provider name | `"Gemini"` |
| providers.ollama.config | object | Ollama configuration | `{"host":"host.docker.internal:11434","options":{"num_ctx":"64000"}}` |
| providers.ollama.config.host | string | Ollama host URL | `"host.docker.internal:11434"` |
| providers.ollama.model | string | Ollama model to use | `"llama3.2"` |
| providers.ollama.provider | string | Provider name | `"Ollama"` |
| providers.openAI.apiKeySecretKey | string | Key in secret containing the OpenAI API key | `"OPENAI_API_KEY"` |
| providers.openAI.apiKeySecretRef | string | Name of secret containing OpenAI API key | `"kagent-openai"` |
| providers.openAI.model | string | OpenAI model to use | `"gpt-4.1-mini"` |
| providers.openAI.provider | string | Provider name | `"OpenAI"` |
| proxy | object | Proxy configuration for decarative agents | `{"url":""}` |
| proxy.url | string | Proxy URL for decarative agents (e.g. "http://proxy.kagent.svc.cluster.local:8080") | `""` |
| querydoc.fullnameOverride | string | Number of querydoc replicas | `"kagent-querydoc"` |
| querydoc.image.name | string | Image name for querydoc image | `"mcp"` |
| querydoc.image.pullPolicy | string | Image pull policy for querydoc | `"IfNotPresent"` |
| querydoc.image.registry | string | Container registry for querydoc image | `"ghcr.io"` |
| querydoc.image.repository | string | Repository for querydoc image | `"kagent-dev/doc2vec"` |
| querydoc.image.tag | string | Tag for querydoc image | `"1.1.13"` |
| querydoc.openai.apiKey | string | OpenAI API key for querydoc | `""` |
| querydoc.replicas | int |  | `1` |
| querydoc.resources | object | Resource requests and limits for querydoc | `{"limits":{"cpu":"500m","memory":"512Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| rbac.clusterScoped | bool | If true, creates ClusterRole and ClusterRoleBinding resources. If false, creates Role and RoleBinding resources instead. | `true` |
| rbac.namespaces | list | When clusterScoped is false, specify additional namespaces to create Roles and RoleBindings in. If empty, defaults to the release namespace. | `[]` |
| rbac.roleMapping | object | Role mapping configuration (only created when oidc.issuer is set) | `{"roleMapper":"claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v])","roleMappings":{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}}` |
| rbac.roleMapping.roleMapper | string | CEL expression to map OIDC claims to roles. Variables: 'claims', 'rolesMap' | `"claims.Groups.transformList(i, v, v in rolesMap, rolesMap[v])"` |
| rbac.roleMapping.roleMappings | object | Map of IdP groups to internal roles (global.Admin, global.Writer, global.Reader) | `{"admins":"global.Admin","readers":"global.Reader","writers":"global.Writer"}` |
| registry | string | Container registry for kagent images | `"cr.kagent.dev"` |
| scaler.enabled | bool | Enable scaler deployment for serverless 0-to-1 scaling | `false` |
| scaler.image.name | string | Image name for the scaler image. | `"kagent-enterprise-scaler"` |
| scaler.image.pullPolicy | string | Image pull policy for scaler | `""` |
| scaler.image.registry | string | Container registry for the scaler image. | `"us-docker.pkg.dev/solo-public"` |
| scaler.image.repository | string | Repository path for the scaler image. | `"kagent-enterprise"` |
| scaler.image.tag | string | Image tag for the scaler image. If unset, defaults to the chart version. | `""` |
| scaler.port | int | HTTP server port for the scaler | `8080` |
| scaler.replicas | int | Number of scaler replicas | `1` |
| scaler.resources | object | Resource requests and limits for scaler | `{"limits":{"cpu":"500m","memory":"256Mi"},"requests":{"cpu":"100m","memory":"128Mi"}}` |
| securityContext | object | Security context for all containers | `{"readOnlyRootFilesystem":true}` |
| tag | string | Default image tag (used when component tag is unset). Empty uses Chart version. | `""` |
| tolerations | list | Node taints to be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| tools.grafana-mcp.enabled | bool | Enable Grafana MCP server for Grafana integration | `false` |
| tools.grafana-mcp.fullnameOverride | string |  | `"kagent-grafana-mcp"` |
| tools.querydoc.enabled | bool | Enable QueryDoc MCP server for documentation queries | `false` |
| ui.enabled | bool |  | `false` |
| ui.env | object | Additional configuration key-value pairs for the UI ConfigMap | `{}` |
| ui.image.name | string | Image name for the UI image | `"ui"` |
| ui.image.pullPolicy | string | Image pull policy for UI | `""` |
| ui.image.registry | string | Container registry for UI image | `"cr.kagent.dev"` |
| ui.image.repository | string | Repository for UI image | `"kagent-dev/kagent"` |
| ui.image.tag | string | Tag for UI image. | `"0.8.5"` |
| ui.nodeSelector | object | Node labels to match for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `{}` |
| ui.podSecurityContext | object | Pod-level security context for the UI pod. Overrides the global podSecurityContext. | (uses global podSecurityContext) |
| ui.replicas | int | Number of UI replicas | `1` |
| ui.resources | object | Resource requests and limits for UI | `{"limits":{"cpu":"1000m","memory":"1Gi"},"requests":{"cpu":"100m","memory":"256Mi"}}` |
| ui.securityContext | object | Container-level security context for the UI container. Overrides the global securityContext. | (uses global securityContext) |
| ui.service.ports.port | int | Service port for UI | `8080` |
| ui.service.ports.targetPort | int | Target port for UI | `8080` |
| ui.service.type | string | Service type for UI | `"ClusterIP"` |
| ui.tolerations | list | Node taints to be tolerated for `Pod` [scheduling](https://kubernetes.io/docs/concepts/scheduling-eviction/assign-pod-node/). | `[]` |
| ui.volumes | object | EmptyDir volume sizes for Next.js UI workload (typically used when enabling readOnlyRootFilesystem) | `{"nextjsCache":"100Mi","tmp":"50Mi"}` |
| ui.volumes.nextjsCache | string | Size limit for Next.js build cache (.next/cache). Default 100Mi is sufficient for typical Next.js apps with moderate caching needs. | `"100Mi"` |
| ui.volumes.tmp | string | Size limit for temporary files (/tmp). Default 50Mi provides ample space for Next.js runtime temporary data. | `"50Mi"` |