# KMCP Enterprise Helm Chart

Enterprise extension for kmcp that provides waypoint translation functionality for MCPServer resources.

## Description

This chart deploys the kmcp-enterprise controller, which extends the base kmcp controller with enterprise-specific translation plugins. The main feature is waypoint gateway translation for MCPServer resources with the `kagent.solo.io/waypoint=true` label.

## Installation

```bash
helm install kmcp-enterprise ./charts/kmcp-enterprise
```

## Configuration

### Global Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| `tag` | Image tag override for all components | `""` (defaults to chart version) |
| `registry` | Container registry for kmcp-enterprise images | `us-docker.pkg.dev/solo-public` |
| `imagePullSecrets` | Image pull secrets for private registries | `[]` |
| `imagePullPolicy` | Image pull policy for all components | `IfNotPresent` |
| `nameOverride` | Override the name of the chart | `""` |
| `fullnameOverride` | Override the full name of the chart | `""` |
| `namespaceOverride` | Override the namespace | `""` |
| `labels` | Additional labels to add to all Kubernetes resources | `{}` |
| `podSecurityContext` | Security context for all pods | `{}` |
| `securityContext` | Security context for all containers | `{}` |

### Controller Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `controller.replicas` | Number of controller replicas | `1` |
| `controller.loglevel` | Log level (debug, info, warn, error) | `info` |
| `controller.image.registry` | Container registry for controller image | `us-docker.pkg.dev/solo-public` |
| `controller.image.repository` | Image repository | `kagent-enterprise/kmcp-enterprise-controller` |
| `controller.image.tag` | Image tag (defaults to global tag, then chart version) | `""` |
| `controller.image.pullPolicy` | Image pull policy for controller | `Always` |
| `controller.resources.requests` | Resource requests | `cpu: 100m, memory: 128Mi` |
| `controller.resources.limits` | Resource limits | `cpu: 500m, memory: 512Mi` |
| `controller.service.type` | Service type | `ClusterIP` |
| `controller.service.ports.metrics` | Service port for metrics | `8080` |
| `controller.service.ports.probe` | Service port for health probe | `8081` |
| `controller.tolerations` | Node taints to be tolerated for Pod scheduling | `[]` |
| `controller.nodeSelector` | Node labels to match for Pod scheduling | `{}` |
| `controller.podSecurityContext` | Security context for controller pods | `{}` |
| `controller.securityContext` | Security context for controller containers | `{}` |
| `controller.env` | Additional environment variables for controller | `[]` |

### ServiceAccount Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.annotations` | Annotations for service account | `{}` |
| `serviceAccount.name` | Name of service account (if not set, uses fullname) | `""` |

### RBAC Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `rbac.create` | Create RBAC resources (ClusterRole, ClusterRoleBinding) | `true` |

## Features

- **Waypoint Translation**: Automatically creates Gateway API and Istio resources for MCPServer resources with the `kagent.solo.io/waypoint=true` label
- **Plugin Architecture**: Uses kmcp's `TranslatorPlugin` extension point
- **Health Checks**: Includes liveness and readiness probes on `/healthz` and `/readyz` endpoints
- **Metrics**: Exposes Prometheus metrics on port 8080
- **Cluster-wide Permissions**: Uses ClusterRole for managing Gateway API and Istio resources across namespaces

## Requirements

- Kubernetes >= 1.24
- kmcp CRDs installed (MCPServer)
- Gateway API CRDs installed (Gateway, HTTPRoute)
- Istio CRDs installed (AuthorizationPolicy)

## Dependencies

This chart is typically deployed as a dependency of the kagent-enterprise chart.

## Resources Created

The chart creates the following Kubernetes resources:

- **Deployment**: The kmcp-enterprise controller deployment
- **Service**: ClusterIP service exposing metrics and health probe endpoints
- **ServiceAccount**: Service account for the controller (if `serviceAccount.create=true`)
- **ClusterRole**: Cluster-wide permissions for MCPServer, Gateway API, Istio, and core Kubernetes resources (if `rbac.create=true`)
- **ClusterRoleBinding**: Binds the ServiceAccount to the ClusterRole (if `rbac.create=true`)

