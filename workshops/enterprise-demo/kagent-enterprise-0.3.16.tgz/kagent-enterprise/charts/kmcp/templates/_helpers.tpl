{{/*
Expand the name of the chart.
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.labels" -}}
helm.sh/chart: {{ include "kmcp.chart" . }}
{{ include "kmcp.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kmcp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kmcp.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Expand the namespace of the release.
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.namespace" -}}
{{- default .Release.Namespace .Values.namespaceOverride | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the image reference.
*/}}
{{- define "kmcp.image" -}}
{{- $registry := .Values.image.registry }}
{{- $repository := .Values.image.repository }}
{{- $name := .Values.image.name }}
{{- $tag := coalesce .Values.image.tag .Chart.Version }}
{{- printf "%s/%s/%s:%s" $registry $repository $name $tag }}
{{- end }}


{{/*
Create controller args.
Matches upstream kmcp chart helper naming.
*/}}
{{- define "kmcp.controllerArgs" -}}
{{- if .Values.controller.metrics.enabled }}
- --metrics-bind-address={{ .Values.controller.metrics.bindAddress }}
{{- end }}
{{- if .Values.controller.healthProbe.bindAddress }}
- --health-probe-bind-address={{ .Values.controller.healthProbe.bindAddress }}
{{- end }}
{{- if .Values.controller.leaderElection.enabled }}
- --leader-elect
{{- end }}
{{- if not .Values.rbac.clusterScoped }}
{{- $namespaces := .Values.rbac.namespaces | default (list (include "kmcp.namespace" .)) }}
- --watch-namespaces={{ join "," $namespaces }}
{{- end }}
{{- end }}

